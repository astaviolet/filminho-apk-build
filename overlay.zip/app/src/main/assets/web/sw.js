/*
 * Filminho — service worker do PWA.
 * Modo "passthrough": NÃO faz cache (nunca serve conteúdo velho — regra
 * do app: sempre a versão mais nova). Ele existe para o site cumprir os
 * critérios de app instalável (iPhone/iOS 16.4+ e Android) e para servir
 * de base para cache offline no futuro.
 */

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (evento) => {
  evento.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (evento) => {
  const pedido = evento.request;
  if (pedido.method !== "GET") return;
  const url = new URL(pedido.url);
  if (url.origin !== self.location.origin) return; // só interfere no próprio site
  evento.respondWith(
    fetch(pedido).catch(() => Response.error()),
  );
});
