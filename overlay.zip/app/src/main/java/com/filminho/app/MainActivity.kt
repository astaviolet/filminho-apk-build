package com.filminho.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.widget.LinearLayout
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var splashView: LinearLayout
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var firstPageLoaded = false
    private var awaitingOAuthReturn = false
    /** Login automático pela conta Google do celular (Chrome) em andamento. */
    private var aguardandoLoginCelular = false
    private var pendingOAuthCallback: String? = null
    private var pendingOAuthError: String? = null
    // Login com Google DENTRO do app (WebView) por padrão. O WebView carrega
    // a tela do Google, o usuário aprova e volta para a origem do app com o
    // código — o supabase-js (detectSessionInUrl) troca o código por sessão.
    // O navegador externo fica apenas como alternativa explícita
    // (botão "abrir no navegador" chama setOAuthExternalBrowser(true)).
    private var oauthPreferExternalBrowser = false
    private val FILE_CHOOSER_REQUEST_CODE = 1001
    private val OAUTH_CALLBACK_SCHEME = "filminho"
    private val OAUTH_CALLBACK_HOST = "oauth-callback"
    private val APP_HOST = "id-preview--33b64d84-f20e-48d9-ae72-6cc3c08d5b91.lovable.app"
    private val APP_ORIGIN = "https://$APP_HOST"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        splashView = findViewById(R.id.splashView)
        webView = findViewById(R.id.webView)
        webView.setBackgroundColor(android.graphics.Color.rgb(5, 5, 7))
        pendingOAuthCallback = intent?.data?.let(::normalizeOAuthCallback)

        // Cookies para login persistir
        try {
            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            cookieManager.setAcceptThirdPartyCookies(webView, true)
        } catch (_: Exception) {}

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.allowFileAccessFromFileURLs = true
        s.allowUniversalAccessFromFileURLs = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.loadsImagesAutomatically = true
        s.blockNetworkImage = false
        s.blockNetworkLoads = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportZoom(false)
        s.userAgentString = s.userAgentString
            .replace("; wv", "")
            .replace(Regex("Version/\\d+\\.\\d+\\s+"), "")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                val host = uri.host ?: return null
                if (host == APP_HOST || host == "filminhoo.lovable.app") {
                    val path = uri.path ?: "/"
                    if (path == "/__apk_fetch") {
                        return executarFetchNativo(uri)
                    }
                    if (path.startsWith("/~oauth") || path == "/filminho.apk" || path == "/filminho-kotlin.apk") {
                        return null
                    }
                    return servirAssetWeb(path)
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (!request.isForMainFrame) return false
                if (baixarArquivoSeForDownload(uri)) return true
                return openGoogleOAuthInBrowser(uri)
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return url?.let {
                    if (baixarArquivoSeForDownload(Uri.parse(it))) true
                    else openGoogleOAuthInBrowser(Uri.parse(it))
                } ?: false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url?.startsWith(APP_ORIGIN) == true || url?.startsWith("https://filminhoo.lovable.app") == true) {
                    garantirCapasVisiveisNoApp(view)
                }
                // O splash só deve sair uma vez. Reanimar alpha em cada navegação
                // fazia a tela piscar ao trocar de rota e durante os redirects do OAuth.
                if (!firstPageLoaded) {
                    firstPageLoaded = true
                    try {
                        webView.animate().cancel()
                        splashView.animate().cancel()
                        webView.alpha = 0f
                        webView.visibility = View.VISIBLE
                        splashView.animate()
                            .alpha(0f)
                            .setDuration(220)
                            .withEndAction { splashView.visibility = View.GONE }
                            .start()
                        webView.animate().alpha(1f).setDuration(180).start()
                    } catch (_: Exception) {
                        splashView.visibility = View.GONE
                        webView.visibility = View.VISIBLE
                        webView.alpha = 1f
                    }
                    deliverPendingOAuthResult()
                }
                // Salva cookies para login persistir
                try { CookieManager.getInstance().flush() } catch (_: Exception) {}
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // (window.open: o player "Assistir" usa a ponte FilminhoShell.openVideo,
            // que abre a PlayerActivity — tela cheia, SEM iframe.)

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                try {
                    val intent = (fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT)).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/mp4", "video/webm", "video/quicktime"))
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE)
                } catch (_: Exception) {
                    this@MainActivity.filePathCallback = null
                    return false
                }
                return true
            }
        }

        // Downloads: APK vai pro DownloadManager (com notificação de progresso);
        // qualquer outro arquivo segue abrindo no app de destino.
        webView.setDownloadListener { url, _, _, mimeType, _ ->
            val uri = Uri.parse(url)
            val ehApk = mimeType?.contains("android") == true || uri.path?.endsWith(".apk") == true
            if (ehApk) {
                baixarArquivoSeForDownload(uri)
            } else {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {}
            }
        }

        // O site pinta o fundo do WebView. Aqui mudamos somente as barras do
        // sistema: repintar o fundo nativo a cada troca limpava a camada do
        // WebView e fazia a tela piscar, especialmente ao escolher tema claro.
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun setTema(bg: String, claro: Boolean) {
                runOnUiThread {
                    try {
                        // `bg` também pode ser um gradiente CSS; use a primeira
                        // cor sólida como aproximação para as barras Android.
                        val hex = Regex("#[0-9a-fA-F]{6}").find(bg)?.value ?: return@runOnUiThread
                        val cor = android.graphics.Color.parseColor(hex)
                        if (window.statusBarColor != cor) window.statusBarColor = cor
                        if (window.navigationBarColor != cor) window.navigationBarColor = cor

                        val decorView = window.decorView
                        val flags = decorView.systemUiVisibility
                        val flagsDeIconesClaros = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                        val novosFlags = if (claro) {
                            flags or flagsDeIconesClaros
                        } else {
                            flags and flagsDeIconesClaros.inv()
                        }
                        if (flags != novosFlags) decorView.systemUiVisibility = novosFlags
                    } catch (_: Exception) {}
                }
            }

            @JavascriptInterface
            fun setOAuthExternalBrowser(use: Boolean) {
                runOnUiThread { oauthPreferExternalBrowser = use }
            }

            /**
             * Abre a página de um player de streaming em TELA CHEIA, numa
             * activity própria (PlayerActivity) — SEM iframe. Vários players
             * bloqueiam embutimento em iframe ("sandboxed frame"); top-level
             * não tem iframe e toca. Botão voltar devolve o usuário ao app.
             */
            @JavascriptInterface
            fun openVideo(url: String) {
                runOnUiThread {
                    try {
                        val i = Intent(this@MainActivity, PlayerActivity::class.java)
                        i.putExtra("url", url)
                        startActivity(i)
                    } catch (_: Exception) {}
                }
            }

            /**
             * Player NATIVO (ExoPlayer) para stream direto (m3u8/MP4/MKV) —
             * o "método novo" do Assistir: sem player web, sem iframe, sem
             * anti-embed. Controles (play/seek/volume/tela cheia) do Android.
             */
            @JavascriptInterface
            fun playDirect(url: String, title: String) {
                runOnUiThread {
                    try {
                        val i = Intent(this@MainActivity, PlayVideoActivity::class.java)
                        i.putExtra("url", url)
                        i.putExtra("title", title)
                        startActivity(i)
                    } catch (_: Exception) {}
                }
            }

            /**
             * Ponte nova (2026-09): leva junto a legenda PT-BR REAL e o idioma do
             * áudio original. O site já baixou e validou o .srt contra a duração
             * medida do vídeo; aqui só gravamos no cache e passamos o caminho,
             * para não estourar o limite de tamanho do Intent.
             *
             * `playDirect(url, title)` continua existindo de propósito: o site é
             * sempre a versão nova, mas o APK pode ser antigo, e o WebView
             * lançaria exceção se a função sumisse.
             */
            @JavascriptInterface
            fun playDirectV2(payloadJson: String) {
                runOnUiThread {
                    try {
                        val json = JSONObject(payloadJson)
                        val url = json.optString("url", "").trim()
                        if (url.isEmpty()) return@runOnUiThread
                        val i = Intent(this@MainActivity, PlayVideoActivity::class.java)
                        i.putExtra("url", url)
                        i.putExtra("title", json.optString("title", ""))
                        // espelhos p/ rotação em erro no player nativo (opcional:
                        // APK antigo simplesmente ignora o campo)
                        json.optJSONArray("mirrors")?.let { arr ->
                            val lista = ArrayList<String>()
                            for (ix in 0 until arr.length()) {
                                arr.optString(ix, "").trim().takeIf { it.isNotEmpty() }?.let { lista.add(it) }
                            }
                            if (lista.isNotEmpty()) i.putExtra("mirrors", lista.toTypedArray())
                        }
                        json.optString("audioLanguage", "").takeIf { it.isNotBlank() }
                            ?.let { i.putExtra("audioLanguage", it) }
                        json.optString("audioLanguageName", "").takeIf { it.isNotBlank() }
                            ?.let { i.putExtra("audioLanguageName", it) }
                        gravarLegendaNoCache(json.optString("subtitleSrt", ""))
                            ?.let { i.putExtra("subtitlePath", it) }
                        // continuar de onde parou (chave estável do filme)
                        json.optString("movieKey", "").takeIf { it.isNotBlank() }
                            ?.let { i.putExtra("movieKey", it) }
                        // sala "Assistir junto" (id, dono, quem sou eu, Supabase Realtime)
                        json.optJSONObject("sala")?.let { i.putExtra("sala", it.toString()) }
                        // cores do tema escolhido no app (player e chat seguem o tema)
                        json.optJSONObject("tema")?.let { i.putExtra("tema", it.toString()) }
                        startActivity(i)
                    } catch (_: Exception) {}
                }
            }

            /** O site descobre se este APK já tem a sala "Assistir junto" (>= 30). */
            @JavascriptInterface
            fun getVersionCode(): Int = try {
                if (android.os.Build.VERSION.SDK_INT >= 28) {
                    packageManager.getPackageInfo(packageName, 0).longVersionCode.toInt()
                } else {
                    @Suppress("DEPRECATION")
                    packageManager.getPackageInfo(packageName, 0).versionCode
                }
            } catch (_: Exception) { 0 }

            /**
             * Login com a conta Google que já está no celular: abre o Chrome
             * (onde a pessoa já está logada no Google), o site faz o login lá e
             * devolve a sessão para o app por filminho://oauth-callback.
             * Com uma conta só, é praticamente automático.
             */
            @JavascriptInterface
            fun entrarComGoogleDoCelular(): Boolean {
                runOnUiThread { abrirLoginNoNavegador() }
                return true
            }

            /** Salas que o dono encerrou no player (o site tira o "Voltar para a sala"). */
            @JavascriptInterface
            fun salasEncerradas(): String {
                val bruto = getSharedPreferences("filminho_player", MODE_PRIVATE).getString("salas_encerradas", "") ?: ""
                return org.json.JSONArray(bruto.split(',').filter { it.isNotBlank() }).toString()
            }

            /** Folha de compartilhar do Android (o WebView não tem navigator.share). */
            @JavascriptInterface
            fun compartilhar(texto: String) {
                runOnUiThread {
                    try {
                        val envio = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, texto)
                        }
                        startActivity(Intent.createChooser(envio, "Convidar para a sala"))
                    } catch (_: Exception) {}
                }
            }
        }, "FilminhoShell")

        // Site atual desta versão empacotado em assets/web e servido na origem do projeto
        // Link de sala (filminho://sala/<id> ou https://filminhoo.lovable.app/?sala=<id>)
        val salaInicial = intent?.data?.let(::salaDoLink)
        webView.loadUrl(
            if (salaInicial != null) "$APP_ORIGIN/?sala=$salaInicial"
            else APP_ORIGIN,
        )
    }

    private fun mimeDeCaminho(path: String): String {
        val ext = path.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "html", "htm" -> "text/html"
            "js", "mjs" -> "application/javascript"
            "css" -> "text/css"
            "json", "webmanifest" -> "application/json"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "svg" -> "image/svg+xml"
            "ico" -> "image/x-icon"
            "webp" -> "image/webp"
            "woff2" -> "font/woff2"
            "woff" -> "font/woff"
            "xml" -> "application/xml"
            "txt" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    private fun servirAssetWeb(rawPath: String): WebResourceResponse? {
        val limpo = rawPath.trimStart('/')
        val ehRotaSpa = limpo.isEmpty() || !limpo.substringAfterLast('/').contains('.')
        val alvo = if (ehRotaSpa) "web/capacitor-index.html" else "web/$limpo"
        return try {
            val stream = assets.open(alvo)
            val mime = mimeDeCaminho(alvo)
            val charset = if (mime.startsWith("text/") || mime == "application/javascript" || mime == "application/json") "utf-8" else null
            WebResourceResponse(
                mime,
                charset,
                200,
                "OK",
                mapOf(
                    "Access-Control-Allow-Origin" to "*",
                    "Cache-Control" to if (ehRotaSpa) "no-store" else "public, max-age=31536000",
                ),
                stream,
            )
        } catch (_: Exception) {
            if (!limpo.startsWith("assets/")) {
                try {
                    val html = assets.open("web/capacitor-index.html")
                    WebResourceResponse(
                        "text/html",
                        "utf-8",
                        200,
                        "OK",
                        mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-store"),
                        html,
                    )
                } catch (_: Exception) {
                    null
                }
            } else {
                WebResourceResponse(
                    "text/plain",
                    "utf-8",
                    404,
                    "Not Found",
                    mapOf("Access-Control-Allow-Origin" to "*"),
                    ByteArrayInputStream(ByteArray(0)),
                )
            }
        }
    }

    private fun executarFetchNativo(uri: Uri): WebResourceResponse {
        val targetUrl = uri.getQueryParameter("url")?.trim() ?: ""
        if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
            return WebResourceResponse(
                "text/plain",
                "utf-8",
                400,
                "Bad Request",
                mapOf("Access-Control-Allow-Origin" to "*"),
                ByteArrayInputStream(ByteArray(0)),
            )
        }
        val headersJson = uri.getQueryParameter("h") ?: "{}"
        val headersMap = mutableMapOf<String, String>()
        var maxRangeBytes: Long? = null
        try {
            val obj = JSONObject(headersJson)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.optString(k, "").trim()
                if (v.isNotEmpty()) {
                    headersMap[k] = v
                    if (k.equals("range", ignoreCase = true)) {
                        val m = Regex("^bytes=(\\d+)-(\\d+)$", RegexOption.IGNORE_CASE).find(v)
                        if (m != null) {
                            val ini = m.groupValues[1].toLongOrNull() ?: 0L
                            val fim = m.groupValues[2].toLongOrNull() ?: 0L
                            if (fim >= ini) maxRangeBytes = (fim - ini + 1L).coerceAtMost(8L * 1024L * 1024L)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        return try {
            var currentUrl = targetUrl
            var redirects = 0
            var conn: HttpURLConnection? = null
            while (redirects <= 6) {
                val u = URL(currentUrl)
                val c = (u.openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 12_000
                    readTimeout = 15_000
                    requestMethod = "GET"
                    useCaches = false
                }
                var temUa = false
                for ((k, v) in headersMap) {
                    c.setRequestProperty(k, v)
                    if (k.equals("user-agent", ignoreCase = true)) temUa = true
                }
                if (!temUa) {
                    c.setRequestProperty("User-Agent", "Filminho/1.0")
                }
                val code = c.responseCode
                if (code in intArrayOf(301, 302, 303, 307, 308)) {
                    val loc = c.getHeaderField("Location")
                    if (!loc.isNullOrBlank()) {
                        val nextUrl = URL(u, loc).toString()
                        try { c.inputStream?.close() } catch (_: Exception) {}
                        currentUrl = nextUrl
                        redirects++
                        continue
                    }
                }
                conn = c
                break
            }
            val finalConn = conn ?: throw IllegalStateException("sem conexao")
            val upstreamCode = finalConn.responseCode
            val rawStream: InputStream = try {
                if (upstreamCode >= 400) (finalConn.errorStream ?: ByteArrayInputStream(ByteArray(0)))
                else finalConn.inputStream
            } catch (_: Exception) {
                ByteArrayInputStream(ByteArray(0))
            }
            val limite: Long = maxRangeBytes ?: 0L
            val bodyStream: InputStream = if (limite > 0L) {
                object : FilterInputStream(rawStream) {
                    private var restante: Long = limite
                    override fun read(): Int {
                        if (restante <= 0L) return -1
                        val b = super.read()
                        if (b != -1) restante -= 1L
                        return b
                    }
                    override fun read(b: ByteArray, off: Int, len: Int): Int {
                        if (restante <= 0L) return -1
                        val maxLen = len.toLong().coerceAtMost(restante).toInt()
                        val n = super.read(b, off, maxLen)
                        if (n > 0) restante -= n.toLong()
                        return n
                    }
                }
            } else rawStream

            val rawCt = finalConn.contentType ?: "application/octet-stream"
            val mimeType = rawCt.substringBefore(';').trim().ifBlank { "application/octet-stream" }
            val charset = Regex("charset=([^;\\s]+)", RegexOption.IGNORE_CASE).find(rawCt)?.groupValues?.get(1)
            val respHeaders = mutableMapOf(
                "Access-Control-Allow-Origin" to "*",
                "Access-Control-Expose-Headers" to "*",
                "X-Upstream-Status" to upstreamCode.toString(),
                "Cache-Control" to "no-store",
            )
            finalConn.getHeaderField("Content-Range")?.let { respHeaders["Content-Range"] = it }
            finalConn.getHeaderField("Accept-Ranges")?.let { respHeaders["Accept-Ranges"] = it }

            val webViewStatus = when {
                upstreamCode == 206 -> 200
                upstreamCode in 200..599 -> upstreamCode
                else -> 502
            }
            val reason = (finalConn.responseMessage ?: "OK").ifBlank { "OK" }
            WebResourceResponse(mimeType, charset, webViewStatus, reason, respHeaders, bodyStream)
        } catch (_: Exception) {
            WebResourceResponse(
                "text/plain",
                "utf-8",
                502,
                "Bad Gateway",
                mapOf("Access-Control-Allow-Origin" to "*"),
                ByteArrayInputStream(ByteArray(0)),
            )
        }
    }

    /** Extrai o id da sala de um link; null se não for link de sala. */
    private fun salaDoLink(uri: Uri): String? {
        val id = when {
            uri.scheme == "filminho" && uri.host == "sala" -> uri.lastPathSegment
            uri.scheme == "https" && (uri.host == APP_HOST || uri.host == "filminhoo.lovable.app") -> uri.getQueryParameter("sala")
            else -> null
        }?.trim()?.lowercase()
        return id?.takeIf { Regex("^[a-z0-9]{6,24}$").matches(it) }
    }

    /**
     * Algumas versões do WebView adiam imagens lazy em áreas com rolagem própria.
     * Promove os pôsteres TMDB para eager, inclusive nos itens criados depois pela SPA.
     */
    private fun garantirCapasVisiveisNoApp(view: WebView?) {
        val script = """
            (function() {
              if (window.__filminhoPosterObserver) return;
              function eagerPoster(img) {
                if (!img || img.tagName !== 'IMG') return;
                var src = img.currentSrc || img.src || img.getAttribute('src') || '';
                if (src.indexOf('image.tmdb.org') === -1) return;
                if (img.loading !== 'eager') img.loading = 'eager';
              }
              function scan(node) {
                if (!node || node.nodeType !== 1) return;
                eagerPoster(node);
                if (node.querySelectorAll) node.querySelectorAll('img').forEach(eagerPoster);
              }
              scan(document.documentElement);
              window.__filminhoPosterObserver = new MutationObserver(function(records) {
                records.forEach(function(record) {
                  if (record.type === 'childList') record.addedNodes.forEach(scan);
                  else eagerPoster(record.target);
                });
              });
              window.__filminhoPosterObserver.observe(document.documentElement, {
                subtree: true,
                childList: true,
                attributes: true,
                attributeFilter: ['src', 'loading']
              });
            })();
        """.trimIndent()
        view?.evaluateJavascript(script, null)
    }

    /**
     * Grava a legenda PT-BR (texto .srt vindo do site) no cache e devolve o
     * caminho. Devolve null quando não veio legenda — e aí o player nativo não
     * mostra o botão CC, porque não existe faixa para mostrar.
     */
    private fun gravarLegendaNoCache(srt: String): String? {
        if (srt.isBlank()) return null
        return try {
            val pasta = File(cacheDir, "legendas").apply { mkdirs() }
            // não deixa o cache crescer para sempre: mantém as 3 mais recentes
            pasta.listFiles()
                ?.sortedByDescending { it.lastModified() }
                ?.drop(2)
                ?.forEach { runCatching { it.delete() } }
            val arquivo = File(pasta, "pt-BR-${System.currentTimeMillis()}.srt")
            arquivo.writeText(srt, Charsets.UTF_8)
            if (arquivo.length() > 0) arquivo.absolutePath else null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Downloads de arquivo (botão "Baixar APK"): baixa o arquivo público do
     * próprio site com o DownloadManager nativo, sem passar por release do
     * repositório privado nem abrir navegador externo. Retorna true quando interceptou.
     */
    private fun baixarArquivoSeForDownload(uri: Uri): Boolean {
        val host = uri.host ?: return false
        val path = uri.path ?: return false
        val ehDownload =
            ((host == APP_HOST || host == "filminhoo.lovable.app") &&
                (path == "/filminho.apk" || path == "/filminho-kotlin.apk")) ||
                (host == "github.com" && path.contains("/releases/download/")) ||
                (host.endsWith("githubusercontent.com") && path.endsWith(".apk", ignoreCase = true))
        if (!ehDownload) return false
        val nomeArq = path.substringAfterLast('/').ifBlank { "filminho.apk" }
        try {
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val req = DownloadManager.Request(uri)
                .setTitle("Baixando Filminho")
                .setDescription(nomeArq)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.addRequestHeader(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
            )
            dm.enqueue(req)
            runOnUiThread {
                Toast.makeText(this, "Baixando Filminho — confira na notificação", Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) {
            runOnUiThread {
                Toast.makeText(this, "Não foi possível baixar o APK. Tente novamente.", Toast.LENGTH_LONG).show()
            }
        }
        return true
    }

    private fun abrirLoginNoNavegador() {
        val uri = Uri.parse("$APP_ORIGIN/~oauth/initiate?provider=google&redirect_uri=lovable%3A%2F%2Foauth-callback&state=filminho")
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
            val externos = packageManager.queryIntentActivities(intent, 0)
                .map { it.activityInfo.packageName }
                .filter { it != packageName }
            // Chrome primeiro: é nele que a conta Google do celular costuma estar logada
            val alvo = externos.firstOrNull { it == "com.android.chrome" }
                ?: externos.firstOrNull { it.contains("chrome") }
                ?: externos.firstOrNull()
                ?: throw android.content.ActivityNotFoundException("sem navegador")
            intent.setPackage(alvo)
            aguardandoLoginCelular = true
            startActivity(intent)
        } catch (_: Exception) {
            aguardandoLoginCelular = false
            if (::webView.isInitialized) {
                webView.evaluateJavascript("window.dispatchEvent(new Event('filminho:login-celular-voltou'));", null)
            }
        }
    }

    private fun openGoogleOAuthInBrowser(uri: Uri): Boolean {
        if (uri.scheme != "https" || (uri.host != APP_HOST && uri.host != "filminhoo.lovable.app") || uri.path != "/~oauth/initiate") return false
        if (uri.getQueryParameter("provider") != "google") return false
        if (!oauthPreferExternalBrowser) {
            // Padrão: login DENTRO do app. O WebView segue para o Google,
            // o usuário aprova lá e o redirect volta para a origem do app
            // (APP_ORIGIN/?code=... ou #access_token=...), onde o supabase-js
            // conclui a sessão sozinho. Nenhum app externo é aberto.
            return false
        }

        return try {
            // Este host também é um App Link do Filminho. Sem escolher um
            // pacote externo, ACTION_VIEW pode reabrir este próprio Activity
            // em vez de abrir o navegador e iniciar um loop de redirects.
            val browserIntent = Intent(Intent.ACTION_VIEW, uri)
                .addCategory(Intent.CATEGORY_BROWSABLE)
            val externalBrowser = packageManager
                .queryIntentActivities(browserIntent, 0)
                .firstOrNull { it.activityInfo.packageName != packageName }
                ?: throw android.content.ActivityNotFoundException("Nenhum navegador externo disponível")

            // Mantém o redirect_uri web permitido pelo broker. O HTTPS App Link
            // verificado devolve a resposta do navegador para este Activity.
            awaitingOAuthReturn = true
            browserIntent.setPackage(externalBrowser.activityInfo.packageName)
            startActivity(browserIntent)
            true
        } catch (_: Exception) {
            awaitingOAuthReturn = false
            pendingOAuthError = "Não foi possível abrir o navegador para entrar com Google."
            deliverPendingOAuthResult()
            true
        }
    }

    private fun normalizeOAuthCallback(uri: Uri): String? {
        if (uri.scheme == OAUTH_CALLBACK_SCHEME && uri.host == OAUTH_CALLBACK_HOST) return uri.toString()
        val ehLovableScheme = uri.scheme == "lovable" && uri.host == OAUTH_CALLBACK_HOST
        val ehHttpsApp = uri.scheme == "https" && (uri.host == APP_HOST || uri.host == "filminhoo.lovable.app")
        if (!ehLovableScheme && !ehHttpsApp) return null

        val fragmentParams = uri.fragment
            ?.trimStart('?')
            ?.let { Uri.parse("https://oauth-callback.invalid/?$it") }
        fun parameter(name: String): String? =
            uri.getQueryParameter(name) ?: fragmentParams?.getQueryParameter(name)

        val error = parameter("error_description") ?: parameter("error")
        if (!error.isNullOrBlank()) {
            return "$OAUTH_CALLBACK_SCHEME://$OAUTH_CALLBACK_HOST?error=${Uri.encode(error)}"
        }
        val code = parameter("code")
        if (!code.isNullOrBlank()) {
            return "$OAUTH_CALLBACK_SCHEME://$OAUTH_CALLBACK_HOST?code=${Uri.encode(code)}"
        }
        val accessToken = parameter("access_token") ?: return null
        val refreshToken = parameter("refresh_token") ?: return null
        return "$OAUTH_CALLBACK_SCHEME://$OAUTH_CALLBACK_HOST#access_token=${Uri.encode(accessToken)}" +
            "&refresh_token=${Uri.encode(refreshToken)}"
    }

    private fun fallbackOAuthUrl(callback: Uri): String? {
        val fragmentParams = callback.fragment
            ?.trimStart('?')
            ?.let { Uri.parse("https://oauth-callback.invalid/?$it") }
        val code = callback.getQueryParameter("code")
            ?: fragmentParams?.getQueryParameter("code")
        if (!code.isNullOrBlank()) {
            return "$APP_ORIGIN/?code=${Uri.encode(code)}"
        }

        val accessToken = callback.getQueryParameter("access_token")
            ?: fragmentParams?.getQueryParameter("access_token")
        val refreshToken = callback.getQueryParameter("refresh_token")
            ?: fragmentParams?.getQueryParameter("refresh_token")
        if (accessToken.isNullOrBlank() || refreshToken.isNullOrBlank()) return null

        // Último recurso para versões antigas do site sem listener do deep link.
        // O fragmento nunca é enviado ao servidor e o app o remove após a sessão carregar.
        return "$APP_ORIGIN/#access_token=${Uri.encode(accessToken)}" +
            "&refresh_token=${Uri.encode(refreshToken)}&token_type=bearer"
    }

    private fun deliverPendingOAuthResult() {
        if (!firstPageLoaded || !::webView.isInitialized) return

        pendingOAuthCallback?.let { callback ->
            pendingOAuthCallback = null
            val quotedCallback = JSONObject.quote(callback)
            val fallback = fallbackOAuthUrl(Uri.parse(callback))
            val fallbackScript = fallback?.let {
                "window.setTimeout(function(){if(window.__filminhoOAuthCallbackHandled!==true){" +
                    "window.location.replace(${JSONObject.quote(it)});}},1000);"
            } ?: ""
            webView.post {
                webView.evaluateJavascript(
                    "window.__filminhoOAuthCallback=$quotedCallback;" +
                        "window.__filminhoOAuthCallbackHandled=false;" +
                        "window.dispatchEvent(new CustomEvent('filminho:oauth-callback',{detail:$quotedCallback}));" +
                        fallbackScript,
                    null,
                )
            }
        }

        pendingOAuthError?.let { message ->
            pendingOAuthError = null
            val quotedMessage = JSONObject.quote(message)
            webView.post {
                webView.evaluateJavascript(
                    "window.__filminhoOAuthError=$quotedMessage;" +
                        "window.dispatchEvent(new CustomEvent('filminho:oauth-error',{detail:$quotedMessage}));",
                    null,
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val uri = intent.data ?: return
        salaDoLink(uri)?.let { id ->
            // app já aberto: avisa o site para abrir a sala sem recarregar
            if (::webView.isInitialized) {
                webView.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('filminho:sala',{detail:'$id'}));",
                    null,
                )
            }
            return
        }
        val callback = normalizeOAuthCallback(uri)
        if (callback == null) {
            if (awaitingOAuthReturn && uri.scheme == "https" && (uri.host == APP_HOST || uri.host == "filminhoo.lovable.app")) {
                awaitingOAuthReturn = false
                pendingOAuthError = "O Google voltou sem um código de autenticação. Tente entrar novamente."
                deliverPendingOAuthResult()
            }
            return
        }
        awaitingOAuthReturn = false
        aguardandoLoginCelular = false
        pendingOAuthCallback = callback
        deliverPendingOAuthResult()
    }

    override fun onResume() {
        super.onResume()
        if (aguardandoLoginCelular && ::webView.isInitialized) {
            // voltou do Chrome sem a sessão (cancelou ou fechou): o site mostra o login normal
            aguardandoLoginCelular = false
            webView.postDelayed({
                webView.evaluateJavascript("window.dispatchEvent(new Event('filminho:login-celular-voltou'));", null)
            }, 1_200)
        }
        if (!awaitingOAuthReturn || !::webView.isInitialized) return
        awaitingOAuthReturn = false
        webView.postDelayed({
            webView.evaluateJavascript(
                "window.dispatchEvent(new Event('filminho:oauth-resume'));",
                null,
            )
        }, 350)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return
            val result = if (resultCode == RESULT_OK) {
                val uri = data?.data
                if (uri != null) arrayOf(uri) else WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            } else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        try { webView.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }
}
